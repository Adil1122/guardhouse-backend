<?php

namespace App\Services;

class CustomerContactService
{
    //
}
