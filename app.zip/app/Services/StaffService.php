<?php

namespace App\Services;

use App\Models\User;
use App\Models\StaffProfile;
use App\Models\StaffCompliance;
use Illuminate\Support\Facades\Storage;
use App\Http\Resources\StaffComplianceResource;
use App\Http\Resources\StaffProfileResource;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

class StaffService
{
    public function updateStaff(array $data, int $id)
    {
        try {
            $profile = DB::transaction(function () use ($data, $id) {

                $user = User::findOrFail($id);

                // update a column only if data key exists
                $user->update(array_intersect_key($data, array_flip(['first_name', 'last_name'])));
                $updateData = array_filter([
                    'preferred_first_name' => $data['preferred_first_name'] ?? null,
                    'preferred_last_name' => $data['preferred_last_name'] ?? null,
                    'sia_badge_number' => $data['sia_badge_number'] ?? null,
                    'contact_number' => $data['contact_number'] ?? null,
                    'emergency_contact' => $data['emergency_contact'] ?? null,
                    'gender' => $data['gender'] ?? null,
                ], function ($value, $key) use ($data) {
                    return array_key_exists($key, $data);
                }, ARRAY_FILTER_USE_BOTH);

                $profile = StaffProfile::updateOrCreate(['user_id' => $user->id], $updateData);
                return $profile;
            });

            return [
                'success' => true,
                'data' => new StaffProfileResource($profile)
            ];

        } catch (\Throwable $th) {
            Log::error('Customer update error: ' . $th->getMessage());

            return [
                'success' => false,
                'error' => $th->getMessage()
            ];
        }
    }

    public function listCompliances($userId)
    {
        $staff = StaffProfile::with(['compliances.compliance'])->where('user_id', $userId)->first();
        if (!$staff) {
            return ['error' => 'Staff profile not found'];
        }

        return StaffComplianceResource::collection($staff->compliances);
    }

    public function createCompliance($userId, $data, $files = [])
    {
        $staff = StaffProfile::where('user_id', $userId)->first();
        if (!$staff) {
            return ['error' => 'Staff profile not found'];
        }

        $filenames = [];
        if ($files) {
            foreach ($files as $file) {
                $filename = time() . '_' . $file->getClientOriginalName();
                $file->storeAs('compliance-documents', $filename, 'public');
                $filenames[] = $filename;
            }
        }

        $compliance = StaffCompliance::create([
            'staff_profile_id' => $staff->id,
            'compliance_id' => $data['compliance_id'],
            'start_date' => $data['start_date'],
            'end_date' => $data['end_date'],
            'files' => $filenames
        ]);

        return new StaffComplianceResource($compliance);
    }

    public function deleteCompliance($userId, $complianceId)
    {
        $staff = StaffProfile::where('user_id', $userId)->first();
        if (!$staff) {
            return ['error' => 'Staff profile not found'];
        }

        $compliance = StaffCompliance::where('staff_profile_id', $staff->id)->find($complianceId);
        if (!$compliance) {
            return ['error' => 'Compliance record not found'];
        }

        if ($compliance->files && is_array($compliance->files)) {
            foreach ($compliance->files as $file) {
                Storage::delete('public/compliance-documents/' . $file);
            }
        }

        $compliance->delete();

        return ['success' => true];
    }

    public function updateSalary($userId, $data)
    {
        $staff = StaffProfile::where('user_id', $userId)->first();
        if (!$staff) {
            return ['error' => 'Staff profile not found'];
        }

        $staff->update($data);

        return ['success' => true];
    }
}