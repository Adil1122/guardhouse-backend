<?php

namespace App\Rules;

use Closure;
use Illuminate\Contracts\Validation\ValidationRule;

class StaffPrivilegeRule implements ValidationRule
{
    /**
     * Run the validation rule.
     *
     * @param  \Closure(string, ?string=): \Illuminate\Translation\PotentiallyTranslatedString  $fail
     */
    public function validate(string $attribute, mixed $value, Closure $fail): void
    {
        if (!is_array($value)) {
            $fail('Privileges must be an array.');
            return;
        }

        $allowedConfig = config('constants.staff_privileges.supervisor', []);

        foreach ($value as $item => $privileges) {

            if (!isset($allowedConfig[$item])) {
                $fail("Invalid privilege item: {$item}");
                continue;
            }

            if (!is_array($privileges)) {
                $fail("Privileges for {$item} must be an array.");
                continue;
            }

            $allowedForThisItem = $allowedConfig[$item];

            foreach ($privileges as $priv) {
                if (!in_array($priv, $allowedForThisItem)) {
                    $fail("Invalid privilege: {$priv} for item {$item}");
                }
            }
        }
    }
}
