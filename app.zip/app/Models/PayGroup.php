<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Http\Resources\PayGroupResource;

class PayGroup extends Model
{
    protected $fillable = ['mode', 'name', 'base_rate'];

    public static function getResource()
    {
        return PayGroupResource::class;
    }

    /**
     * Validation rules to be used for pay group create or update
     */
    public static function getValidationRules($action)
    {
        $rules = [
            'mode' => 'required|in:hourly,flat',
            'name' => 'required|string|max:50',
            'base_rate' => 'required|numeric|between:0,99999999.99',
        ];

        if ($action === 'store') {
            
        } else if ($action === 'update') {
            
        }

        return $rules;
    }

    public function rates()
    {
        return $this->hasMany(PayRate::class);
    }
}
