<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ShiftResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'site' => $this->site ? ['id' => $this->site_id, 'name' => $this->site->name] : null,
            'service_type' => $this->service_type,
            'start_date' => $this->start_date,
            'end_date' => $this->end_date,
            'timezone' => $this->timezone,
            'start_time' => $this->start_time,
            'end_time' => $this->end_time,
            'break_duration' => $this->break_duration,
            'status' => $this->status,
            'customer_po' => $this->customer_po,
            'service_group' => $this->serviceGroup ? ['id' => $this->serviceGroup->id, 'name' => $this->serviceGroup->name] : null,
            'pay_group' => $this->payGroup ? ['id' => $this->payGroup->id, 'name' => $this->payGroup->name] : null,
            'questionnaire' => $this->questionnaire,
            'assigned_to' => $this->assignedUser ? ['id' => $this->assignedUser->id, 'name' => $this->assignedUser->first_name . ' ' . $this->assignedUser->last_name] : null,
            'created_by' => $this->createdBy ? ['id' => $this->createdBy->id, 'name' => $this->createdBy->first_name . ' ' . $this->createdBy->last_name] : null,
            'created_at' => $this->created_at ? date('Y-m-d H:i A', strtotime($this->created_at)) : null,
        ];
    }
}
