<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class StaffProfileResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $user = $this->user;

        return [
            'profile_id' => $this->id,
            'user_id' => $user->id,
            'role' => $user->role,
            'first_name' => $user->first_name,
            'last_name' => $user->last_name,
            'email' => $user->email,
            'status' => $user->status,
            'image' => $user->image,
            'preferred_first_name' => $this->preferred_first_name,
            'preferred_last_name' => $this->preferred_last_name,
            'sia_badge_number' => $this->sia_badge_number,
            'contact_number' => $this->contact_number,
            'emergency_contact' => $this->emergency_contact,
            'gender' => $this->gender,
            'bank_details' => $this->bank_details,
            'tax_number' => $this->tax_number,
            'default_pay_group_id' => $this->default_pay_group_id,
            'email_verified_at' => $user->email_verified_at
        ];
    }
}
