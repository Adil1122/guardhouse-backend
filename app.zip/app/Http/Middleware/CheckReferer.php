<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CheckReferer
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next)
    {
        $allowedDomains = config('constants.allowed_referers'); 
        $referer = $request->headers->get('referer');

        if (!$referer) {
            return response()->json(['message' => 'Request not allowed'], 403);
        }

        $refererHost = parse_url($referer, PHP_URL_HOST);

        $isAllowed = false;

        foreach ($allowedDomains as $allowed) {
            $allowedHost = parse_url($allowed, PHP_URL_HOST) ?? $allowed;

            if ($refererHost === $allowedHost) {
                $isAllowed = true;
                break;
            }
        }

        if (!$isAllowed) {
            return response()->json(['message' => 'Request not allowed'], 403);
        }

        return $next($request);
    }
}
