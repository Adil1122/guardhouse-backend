<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\BaseController;
use App\Models\Form;
use App\Services\FormService;

class FormController extends BaseController
{
    protected $filterKey = null;
    protected $service;

    public function __construct(FormService $service)
    {
        parent::__construct(new Form());
        $this->service = $service;
    }

    public function updateElementOrder(\Illuminate\Http\Request $request, $id)
    {
        $request->validate([
            'form_element_id' => 'required|exists:form_elements,id,form_id,' . $id,
            'direction' => 'required|in:up,down',
        ]);

        $result = $this->service->updateElementOrder($id, $request->only(['form_element_id', 'direction']));
        if ($result['success']) {
            return response()->json(['success' => true], 200);
        }

        return response()->json(['success' => false, 'error' => $result['error'],  'error_code' => $result['error_code']], $result['error_code']);
    }
}
