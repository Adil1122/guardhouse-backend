<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\BaseController;
use App\Models\CustomerInvoiceProfile;
use App\Services\CustomerInvoiceProfileService;

class CustomerInvoiceProfileController extends BaseController
{
    protected $filterKey = 'customer_profile_id';
    protected $service;

    public function __construct(CustomerInvoiceProfileService $service)
    {
        parent::__construct(new CustomerInvoiceProfile());
        $this->service = $service;
    }
}
