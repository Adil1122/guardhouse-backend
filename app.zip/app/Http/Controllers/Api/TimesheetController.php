<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\BaseController;
use Illuminate\Http\Request;
use App\Models\Timesheet;
use App\Services\TimesheetService;

class TimesheetController extends BaseController
{
    protected $filterKey = null;
    protected $service;

    public function __construct(TimesheetService $service)
    {
        parent::__construct(new Timesheet());
        $this->service = $service;
    }
}
