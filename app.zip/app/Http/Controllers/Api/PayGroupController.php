<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\BaseController;
use App\Models\PayGroup;
use App\Services\PayGroupService;

class PayGroupController extends BaseController
{
    protected $filterKey = null;
    protected $service;

    public function __construct(PayGroupService $service)
    {
        parent::__construct(new PayGroup());
        $this->service = $service;
    }
}
