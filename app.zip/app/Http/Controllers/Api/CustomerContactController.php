<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\BaseController;
use App\Models\CustomerContact;
use App\Services\CustomerContactService;

class CustomerContactController extends BaseController
{
    protected $filterKey = 'customer_profile_id';
    protected $service;

    public function __construct(CustomerContactService $service)
    {
        parent::__construct(new CustomerContact());
        $this->service = $service;
    }
}
