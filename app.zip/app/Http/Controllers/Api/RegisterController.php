<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Services\RegisterService;
use App\Rules\EmergencyContactRule;
use App\Rules\BankDetailRule;

class RegisterController extends Controller
{
    protected $service;

    public function __construct(RegisterService $service)
    {
        $this->service = $service;
    }

    public function signup(Request $request)
    {
        $allowedRoles = auth()->user()->role === 'admin' ? ['admin', 'supervisor', 'security-officer'] : ['security-officer'];

        $validated = $request->validate([
            'role' => 'required|in:' . implode(',', $allowedRoles),
            'first_name' => 'required|string|max:50',
            'last_name' => 'required|string|max:50',
            'email' => 'required|email|unique:users,email',
            'preferred_first_name' => 'required|string|max:50',
            'preferred_last_name' => 'required|string|max:50',
            'sia_badge_number' => 'required|string|max:50',
            'contact_number' => 'required|string|max:50',
            'emergency_contact' => ['nullable', new EmergencyContactRule()],
            'gender' => 'required|in:male,female,other'
        ]);

        $result = $this->service->signupStaff($validated);
        if (isset($result['error'])) {
            return response()->json(['message' => $result['error']], 401);
        }

        return response()->json($result, 201);
    }
}
