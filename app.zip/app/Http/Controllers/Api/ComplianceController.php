<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\BaseController;
use Illuminate\Http\Request;
use App\Services\OrganizationComplianceService;
use App\Models\OrganizationCompliance;

class ComplianceController extends BaseController
{
    protected $service;
    protected $filterKey = null;

    public function __construct(OrganizationComplianceService $service)
    {
        parent::__construct(new OrganizationCompliance());
        $this->service = $service;
    }
}
