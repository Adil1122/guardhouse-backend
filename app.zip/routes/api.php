<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\RegisterController;
use App\Http\Controllers\Api\CustomerController;
use App\Http\Controllers\Api\SiteController;
use App\Http\Controllers\Api\StaffController;
use App\Http\Controllers\Api\ComplianceController;
use App\Http\Controllers\Api\CustomerContactController;
use App\Http\Controllers\Api\CustomerInvoiceProfileController;
use App\Http\Controllers\Api\SiteContactController;
use App\Http\Controllers\Api\PayGroupController;
use App\Http\Controllers\Api\ServiceGroupController;
use App\Http\Controllers\Api\FormController;
use App\Http\Controllers\Api\OrganizationController;
use App\Http\Controllers\Api\SitePreferenceController;
use App\Http\Controllers\Api\SiteCheckpointController;
use App\Http\Controllers\Api\SiteDocumentController;
use App\Http\Controllers\Api\SiteAccessCodeController;
use App\Http\Controllers\Api\ShiftController;
use App\Http\Controllers\Api\ShiftNoteController;
use App\Http\Controllers\Api\TimesheetController;
use App\Http\Controllers\Api\InvoiceController;
use App\Http\Controllers\Api\ShiftTimeClockLogController;

Route::prefix('auth')->group(function () {
    Route::middleware(['throttle:login', 'check.honeypot'])->post('login', [AuthController::class, 'login']);
    Route::post('/forget-password', [AuthController::class, 'forgetPassword']);
    Route::post('/verify-reset-password-token', [AuthController::class, 'verifyResetPasswordToken']);
    Route::post('/reset-password', [AuthController::class, 'resetPassword']);
    Route::post('/activate-user', [AuthController::class, 'activateUser']);
});

Route::middleware(['auth:sanctum', 'ensure.user.access', 'check.referer'])->group(function () {
    
    Route::middleware('ability:admin')->group(function () {
        
        Route::middleware(['throttle:signup', 'check.honeypot'])->post('auth/signup', [RegisterController::class, 'signup']); // rate limiting + honeypot checking middlewares in place
        
        Route::prefix('users/{id}/privileges')->group(function () {
            Route::get('', [StaffController::class, 'listPrivileges'])->name('user.privilege.list');
            Route::patch('', [StaffController::class, 'updatePrivileges'])->name('user.privilege.update');
        });

        Route::prefix('organization')->group(function () {
            Route::prefix('compliances')->group(function () {
                Route::get('', [ComplianceController::class, 'index'])->name('organization_compliance.list');
                Route::get('paginated/{page}/{filter?}', [ComplianceController::class, 'paginatedList'])->name('organization_compliance.list');
                Route::post('', [ComplianceController::class, 'store'])->name('organization_compliance.create');
                Route::patch('{id}', [ComplianceController::class, 'update'])->name('organization_compliance.update');
                Route::delete('{id}', [ComplianceController::class, 'destroy'])->name('organization_compliance.delete');
            });

            Route::patch('settings', [OrganizationController::class, 'settings'])->name('organization.settings');
        });
    });

    Route::prefix('shifts')->group(function () {
        Route::get('', [ShiftController::class, 'index'])->name('shift.list');
        Route::get('paginated/{page}/{filter?}', [ShiftController::class, 'paginatedList'])->name('shift.list');
        Route::post('', [ShiftController::class, 'store'])->name('shift.create');
        Route::patch('{id}', [ShiftController::class, 'update'])->name('shift.update');
        Route::delete('{id}', [ShiftController::class, 'destroy'])->name('shift.delete');

        Route::prefix('{shiftId}/notes')->middleware('bind.shift.id')->group(function () {
            Route::get('', [ShiftNoteController::class, 'index'])->name('shift.notes');
            Route::post('', [ShiftNoteController::class, 'store'])->name('shift.notes');
            Route::patch('{id}', [ShiftNoteController::class, 'update'])->name('shift.notes');
            Route::delete('{id}', [ShiftNoteController::class, 'destroy'])->name('shift.notes');
        });
        
        Route::prefix('{shiftId}/submission')->middleware('bind.shift.id')->group(function () {
            Route::post('timeclock', [ShiftTimeClockLogController::class, 'store'])->name('shift_submission.timeclock.create')->middleware('bind.shift.clock.in.out.time');
        });

    });
    
    Route::prefix('timesheets')->group(function () {
        Route::get('', [TimesheetController::class, 'index'])->name('timesheet.list');
        Route::get('paginated/{page}/{filter?}', [TimesheetController::class, 'paginatedList'])->name('timesheet.list');
        Route::patch('{id}', [TimesheetController::class, 'update'])->name('timesheet.update')->middleware('can.edit.timesheet');
    });

    Route::prefix('customers')->group(function () {
        Route::get('', [CustomerController::class, 'index'])->name('customer.list');
        Route::get('paginated/{page}/{filter?}', [CustomerController::class, 'paginatedList'])->name('customer.list');
        Route::post('', [CustomerController::class, 'store'])->name('customer.create');
        Route::patch('{id}', [CustomerController::class, 'update'])->name('customer.update');
        Route::delete('{id}', [CustomerController::class, 'destroy'])->name('customer.delete');

        Route::prefix('{userId}/sites')->middleware('bind.customer.profile.id')->group(function () {
            Route::get('', [CustomerController::class, 'sitesList'])->name('customer.site');
            Route::post('', [CustomerController::class, 'attachSite'])->name('customer.site');
            Route::delete('{id}', [CustomerController::class, 'detachSite'])->name('customer.site');
        });

        Route::prefix('{userId}/contacts')->middleware('bind.customer.profile.id')->group(function () {
            Route::get('', [CustomerContactController::class, 'index'])->name('customer.contact');
            Route::get('paginated/{page}/{filter?}', [CustomerContactController::class, 'paginatedList'])->name('customer.contact');
            Route::post('', [CustomerContactController::class, 'store'])->name('customer.contact');
            Route::patch('{id}', [CustomerContactController::class, 'update'])->name('customer.contact');
            Route::delete('{id}', [CustomerContactController::class, 'destroy'])->name('customer.contact');
        });
        
        Route::prefix('{userId}/invoice-profiles')->middleware('bind.customer.profile.id')->group(function () {
            Route::get('', [CustomerInvoiceProfileController::class, 'index'])->name('customer.invoice_profile');
            Route::get('paginated/{page}/{filter?}', [CustomerInvoiceProfileController::class, 'paginatedList'])->name('customer.invoice_profile');
            Route::post('', [CustomerInvoiceProfileController::class, 'store'])->name('customer.invoice_profile');
            Route::patch('{id}', [CustomerInvoiceProfileController::class, 'update'])->name('customer.invoice_profile');
            Route::delete('{id}', [CustomerInvoiceProfileController::class, 'destroy'])->name('customer.invoice_profile');
        });
    });
    
    Route::prefix('sites')->group(function () {
        Route::get('', [SiteController::class, 'index'])->name('static_site.list');
        Route::get('paginated/{page}/{filter?}', [SiteController::class, 'paginatedList'])->name('static_site.list');
        Route::post('', [SiteController::class, 'store'])->name('static_site.create');
        Route::patch('{id}', [SiteController::class, 'update'])->name('static_site.update');
        Route::delete('{id}', [SiteController::class, 'destroy'])->name('static_site.delete');

        Route::prefix('{siteId}/contacts')->middleware('bind.site.id')->group(function () {
            Route::get('', [SiteContactController::class, 'index'])->name('static_site.contact');
            Route::get('paginated/{page}/{filter?}', [SiteContactController::class, 'paginatedList'])->name('static_site.contact');
            Route::post('', [SiteContactController::class, 'store'])->name('static_site.contact');
            Route::patch('{id}', [SiteContactController::class, 'update'])->name('static_site.contact');
            Route::delete('{id}', [SiteContactController::class, 'destroy'])->name('static_site.contact');
        });
        
        Route::prefix('{siteId}/preferences')->middleware('bind.site.id')->group(function () {
            Route::get('', [SitePreferenceController::class, 'index'])->name('static_site.preference');
            Route::get('paginated/{page}/{filter?}', [SitePreferenceController::class, 'paginatedList'])->name('static_site.preference');
            Route::post('', [SitePreferenceController::class, 'store'])->name('static_site.preference');
            Route::patch('{id}', [SitePreferenceController::class, 'update'])->name('static_site.preference');
            Route::delete('{id}', [SitePreferenceController::class, 'destroy'])->name('static_site.preference');
        });

        Route::prefix('{siteId}/checkpoints')->middleware('bind.site.id')->group(function () {
            Route::get('', [SiteCheckpointController::class, 'index'])->name('static_site.checkpoint');
            Route::get('paginated/{page}/{filter?}', [SiteCheckpointController::class, 'paginatedList'])->name('static_site.checkpoint');
            Route::post('', [SiteCheckpointController::class, 'store'])->name('static_site.checkpoint');
            Route::patch('{id}', [SiteCheckpointController::class, 'update'])->name('static_site.checkpoint');
            Route::delete('{id}', [SiteCheckpointController::class, 'destroy'])->name('static_site.checkpoint');
        });
        
        Route::prefix('{siteId}/documents')->middleware('bind.site.id')->group(function () {
            Route::get('', [SiteDocumentController::class, 'index'])->name('static_site.document');
            Route::get('paginated/{page}/{filter?}', [SiteDocumentController::class, 'paginatedList'])->name('static_site.document');
            Route::post('', [SiteDocumentController::class, 'store'])->name('static_site.document');
            Route::patch('{id}', [SiteDocumentController::class, 'update'])->name('static_site.document');
            Route::delete('{id}', [SiteDocumentController::class, 'destroy'])->name('static_site.document');
            Route::post('{id}/upload-files', [SiteDocumentController::class, 'uploadFiles'])->name('static_site.document');
            Route::delete('{id}/delete-file', [SiteDocumentController::class, 'deleteFile'])->name('static_site.document');
        });
        
        Route::prefix('{siteId}/access-codes')->middleware('bind.site.id')->group(function () {
            Route::get('', [SiteAccessCodeController::class, 'index'])->name('static_site.access_code');
            Route::get('paginated/{page}/{filter?}', [SiteAccessCodeController::class, 'paginatedList'])->name('static_site.access_code');
            Route::post('', [SiteAccessCodeController::class, 'store'])->name('static_site.access_code');
            Route::patch('{id}', [SiteAccessCodeController::class, 'update'])->name('static_site.access_code');
            Route::delete('{id}', [SiteAccessCodeController::class, 'destroy'])->name('static_site.access_code');
        });
    });
    
    Route::prefix('staff')->group(function () {
        Route::get('', [StaffController::class, 'index'])->name('staff.list');
        Route::get('paginated/{page}/{filter?}', [StaffController::class, 'paginatedList'])->name('staff.list');
        Route::middleware(['throttle:signup', 'check.honeypot'])->post('', [RegisterController::class, 'signup'])->name('staff.create'); // rate limiting + honeypot checking middlewares in place
        Route::patch('{id}', [StaffController::class, 'update'])->name('staff.update');
        Route::delete('{id}', [StaffController::class, 'destroy'])->name('staff.delete');
        
        Route::patch('{id}/salary', [StaffController::class, 'updatePaySalary'])->name('staff.salary');
        Route::patch('{id}/privilege', [StaffController::class, 'updatePrivilege'])->name('staff.privilege');
        Route::get('{id}/privilege', [StaffController::class, 'listPrivileges'])->name('staff.privilege');
        Route::prefix('{userId}/compliances')->group(function () {
            Route::get('', [StaffController::class, 'listCompliances'])->name('staff.compliance');
            Route::post('', [StaffController::class, 'createCompliance'])->name('staff.compliance');
            Route::delete('', [StaffController::class, 'deleteCompliance'])->name('staff.compliance');
        });
    });

    Route::prefix('pay-groups')->group(function () {
        Route::get('', [PayGroupController::class, 'index'])->name('pay_group.list');
        Route::get('paginated/{page}/{filter?}', [PayGroupController::class, 'paginatedList'])->name('pay_group.list');
        Route::post('', [PayGroupController::class, 'store'])->name('pay_group.create');
        Route::patch('{id}', [PayGroupController::class, 'update'])->name('pay_group.update');
        Route::delete('{id}', [PayGroupController::class, 'destroy'])->name('pay_group.delete');
    });

    Route::prefix('service-groups')->group(function () {
        Route::get('', [ServiceGroupController::class, 'index'])->name('service_group.list');
        Route::get('paginated/{page}/{filter?}', [ServiceGroupController::class, 'paginatedList'])->name('service_group.list');
        Route::post('', [ServiceGroupController::class, 'store'])->name('service_group.create');
        Route::patch('{id}', [ServiceGroupController::class, 'update'])->name('service_group.update');
        Route::delete('{id}', [ServiceGroupController::class, 'destroy'])->name('service_group.delete');
    });

    Route::prefix('forms')->group(function () {
        Route::get('{filter?}', [FormController::class, 'index'])->name('form.list');
        Route::get('paginated/{page}/{filter?}', [FormController::class, 'paginatedList'])->name('form.list');
        Route::post('', [FormController::class, 'store'])->name('form.create');
        Route::patch('{id}', [FormController::class, 'update'])->name('form.update');
        Route::delete('{id}', [FormController::class, 'destroy'])->name('form.delete');
        Route::patch('{id}/update-element-order', [FormController::class, 'updateElementOrder'])->name('form.update');
    });
    
    Route::prefix('invoices')->group(function () {
        Route::get('{filter?}', [InvoiceController::class, 'index'])->name('invoice.list');
        Route::get('paginated/{page}/{filter?}', [InvoiceController::class, 'paginatedList'])->name('invoice.list');
        Route::post('', [InvoiceController::class, 'store'])->name('invoice.create');
        Route::patch('{id}', [InvoiceController::class, 'update'])->name('invoice.update')->middleware('can.edit.invoice');
        Route::delete('{id}', [InvoiceController::class, 'destroy'])->name('invoice.delete');
        Route::patch('{id}/complete', [InvoiceController::class, 'complete'])->name('invoice.complete');
    });
});