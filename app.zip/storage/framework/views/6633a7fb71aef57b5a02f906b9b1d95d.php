<?php $__env->startComponent('mail::message'); ?>
# Invoice Approved

Hello <?php echo new \Illuminate\Support\EncodedHtmlString($customerName); ?>,

We are pleased to inform you that your invoice **#<?php echo new \Illuminate\Support\EncodedHtmlString($invoice->reference_number); ?>** has been **approved**.

<?php $__env->startComponent('mail::table'); ?>
| Item | Type | Amount |
|------|------|-------|
<?php $__currentLoopData = $invoice->invoiceItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
| <?php echo new \Illuminate\Support\EncodedHtmlString($item->reference_type); ?> #<?php echo new \Illuminate\Support\EncodedHtmlString($item->reference_id); ?> | <?php echo new \Illuminate\Support\EncodedHtmlString(ucfirst($item->reference_type)); ?> | $<?php echo new \Illuminate\Support\EncodedHtmlString(number_format($item->reference->service_total_amount ?? 0, 2)); ?> |
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo $__env->renderComponent(); ?>

**Subtotal:** $<?php echo new \Illuminate\Support\EncodedHtmlString(number_format($invoice->sub_total, 2)); ?> 
**Grand Total:** $<?php echo new \Illuminate\Support\EncodedHtmlString(number_format($invoice->grand_total, 2)); ?>  

Please review the invoice at your earliest convenience.  
If you have any questions, feel free to contact us.

Thank you for your business!  

Regards,  
**<?php echo new \Illuminate\Support\EncodedHtmlString(config('app.name')); ?> Team**
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\guardhouse\backend\resources\views/emails/invoice-approved.blade.php ENDPATH**/ ?>